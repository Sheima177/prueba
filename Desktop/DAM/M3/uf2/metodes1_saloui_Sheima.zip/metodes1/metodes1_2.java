package metodes1;
import java.util.Scanner;
public class metodes1_2 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		System.out.println("Calcula la mitjana aritmetica de 3 numeros i quin numero dels que hem introduït és el més petit");

		int x, y, z;

		do {
			System.out.print("Entra el primer número: ");
			while (!in.hasNextInt()) {
				System.err.println(" Número no vàlid. Torna a introduir el primer número: ");
				in.next();
			}
			x = in.nextInt();
		} while (x <= 0);

		// Valida i llegeix el seguent numero
		do {
			System.out.print("\nEntra el següent número: ");
			while (!in.hasNextInt()) {
				System.err.println("Número no vàlid. Torna a introduir el següent número: ");
				in.next(); 
			}
			y = in.nextInt();
		} while (y <= 0);

		// valida i llegeix el seguent numero
		do {
			System.out.print("\nEntra el últim número: ");
			while (!in.hasNextInt()) {
				System.err.println("Número no vàlid. Torna a introduir l'últim número: ");
				in.next(); 
			}
			z = in.nextInt();
		} while (z <= 0);

		System.out.println("El minim és "+minim(x,y,z));
		System.out.println("La mitjana aritmetica de "+x+" + "+y+" + "+z+" = "+mitjanaAritmetica(x,y,z));

		testMinim();
		testMitjanaAritmetica();

		in.close();
	}


	public static double minim(double x, double y, double z) {
		if(x < y && y < z) {
			return x;
		}else if(y < x & x < z) {
			return y;
		}else {
			return z;
		}

	}

	public static double mitjanaAritmetica(double x, double y, double z) {
		double arithmetic = (x + y + z) / 3;
		return arithmetic;
	}

	// proves realitzades amb 3 casos diferents:	
	public static void testMinim() {
		System.out.println(minim(23, 21, 21) == 21.0) ;
		System.out.println(minim(10, 17, 25) == 10.0) ;
		System.out.println(minim(100, 243, 89) == 89.0) ;

		System.out.println("El numero mínim funciona correctament");
	}


	public static void testMitjanaAritmetica() {
		System.out.println(mitjanaAritmetica(23, 21, 21)== 21.666666668) ;
		System.out.println(mitjanaAritmetica(10, 17, 25) == 17.333333332) ;
		System.out.println(mitjanaAritmetica(100, 243, 89)== 144.0) ;



		System.out.println("Proves ok!");

	}

}







