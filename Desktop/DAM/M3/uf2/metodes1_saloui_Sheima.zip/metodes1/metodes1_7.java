package metodes1;

public class metodes1_7 {


	public class Metode1_7 {

	    public static void main(String[] args) {
	        // Función de prueba
	        testMatrixEquality();
	    }

	    public static boolean areArraysEqual(int[] a, int[] b) {
	        if (a == b) {
	            return true;
	        }

	        if (a == null || b == null || a.length != b.length) {
	            return false;
	        }

	        for (int i = 0; i < a.length; i++) {
	            if (a[i] != b[i]) {
	                return false;
	            }
	        }

	        return true;
	    }

	    public static void testMatrixEquality() {
	        int[] matrix1 = {1, 2, 3, 4, 5};
	        int[] matrix2 = {1, 2, 3, 4, 5};
	        int[] matrix3 = {5, 4, 3, 2, 1};
	        int[] matrix4 = {1, 2, 3, 4};

	        // Comprueba si matrix1 es igual a matrix2 (debe ser verdadero)
	        System.out.println("Matrix 1 equals Matrix 2: " + areArraysEqual(matrix1, matrix2));

	        // Comprueba si matrix1 es igual a matrix3 (debe ser falso)
	        System.out.println("Matrix 1 equals Matrix 3: " + areArraysEqual(matrix1, matrix3));

	        // Comprueba si matrix1 es igual a matrix4 (debe ser falso)
	        System.out.println("Matrix 1 equals Matrix 4: " + areArraysEqual(matrix1, matrix4));
	    }
	}

}
