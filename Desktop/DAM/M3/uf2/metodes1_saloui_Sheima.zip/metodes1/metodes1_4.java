
package metodes1;
import java.util.Scanner;
public class metodes1_4 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);

		System.out.println(" Primer i ultim digit del numero introduit, i numero dels digits introduïuts");
		System.out.print("Entra un numero :");
		int num = in.nextInt();

		System.out.println("Primer dígit: " + primerDigit(num));
		System.out.println("Últim dígit: " + ultimDigit(num));
		System.out.println("Nombre de dígits: " + contaDigits(num));

		in.close();
	}

	// obtenir primer dígit
	public static int primerDigit(int n) {
		// Converteix el número a una cadena de caràcters
		String numString = Integer.toString(n);

		// Retorna el primer caràcter convertit a l'enter
		return Character.getNumericValue(numString.charAt(0));
	}

	// obtenir l'últim dígit
	public static int ultimDigit(int n) {
		// Obté el residu quan es divideix el número per 10
		return n % 10;
	}

	// contar el nombre de dígits
	public static int contaDigits(int n) {
		// Converteix el número a una cadena de caràcters i retorna la seva longitud
		return Integer.toString(n).length();
	}
}

		
		
		
		
		
		
		
		


