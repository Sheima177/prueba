package metodes1;

public class metodes1_1 {

	public static void main(String[] args) {
		int[] numN = {4, -2, -2, -5, 7, 5};
		int[] numM = {7, 5, -5, -2, 7, 2};

		for (int i = 0; i < numN.length; i++) {
			System.out.println("Suma entre " + numN[i] + " i " + numM[i] + ": " + sumaRang(numN[i], numM[i]));
		}
		testSumaRang();
	}

	public static int sumaRang(int numN, int numM) {
		int sum = 0;

		for (int i = Math.min(numN, numM); i <= Math.max(numN, numM); i++) {
			sum += i;
		}
		return sum;
	}



	// Test del programa
	public static void testSumaRang() {
		System.out.println(sumaRang(4, 7)==22) ;
		System.out.println( sumaRang(-2, 5) == 12);
		System.out.println( sumaRang(-2, -5) == -14);
		System.out.println( sumaRang(-5, -2) == -14);
		System.out.println( sumaRang(7, 7) == 7);
		System.out.println( sumaRang(5, 2) == 14);

		System.out.println("test ok!");
	}
}	




















