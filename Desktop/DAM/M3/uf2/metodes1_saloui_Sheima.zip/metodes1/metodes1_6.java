package metodes1;
import java.util.Random;
import java.util.Scanner;
public class metodes1_6 {
	

	

		public static void main(String[] args) {
			Scanner in = new Scanner(System.in);

			//Declaració de variables
			System.out.println("Creem una matriu de dimensio X i l'omplirem aleatoriament amb 0 i 1.");
			System.out.println("Entra la dimensió de la matriu");
	        int dimensio = in.nextInt(); //Canvi de dimensió segons les necessitats
	        //Generem la matriu
	        int[][] matriu = generarMatriuBinaria(dimensio);
	        
	        //mostrem el resultat de la matriu que hem creat
	        mostrarMatriu(matriu);
	        
	        in.close();
	    }

	    // Genera una matriu binària de mida dimensio x dimensio
	    public static int[][] generarMatriuBinaria(int dimensio) {
	        int[][] matriu = new int[dimensio][dimensio];
	        Random random = new Random();

	        // Bucle per omplir cada element de la matriu amb 0 o 1 de  aleatòriament
	        for (int i = 0; i < dimensio; i++) {
	            for (int j = 0; j < dimensio; j++) {
	                matriu[i][j] = random.nextInt(2); // Genera 0 o 1 de manera aleatòria
	            }
	        }
	        return matriu;
	    }

	    // Mostra una matriu de dues dimensions
	    public static void mostrarMatriu(int m[][]) {
	        int dimensio = m.length;

	        // Bucle per imprimir cada element de la matriu en format de matriu
	        for (int i = 0; i < dimensio; i++) {
	            for (int j = 0; j < dimensio; j++) {
	                System.out.print(m[i][j] + " ");
	            }
	            System.out.println(); // Nova línia després de cada fila
	        }
	    }
	}
		
		
		
		
		
		
		
		
		


