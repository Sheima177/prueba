
package metodes1;
import java.util.Scanner;
public class metodes1_5 {
	

		
		public static void main(String[] args) {
	        Scanner in = new Scanner(System.in);
	        
	        System.out.println("Rretorna el caracter o caracters centrals d'una paraula.");
	        System.out.println("\"EX: 'Programar' té longitud parell i retorna 'og'.\"");
	        
	        System.out.println("Entra una paraula: ");
			// Exemple d'ús
	        String input1 = in.next();//"abc";
	        String result1 = caractersCentrals(input1);
	        System.out.println("El resultat és: "+result1);  

	        System.out.println("Entra una altre paraula: ");
	        String input2 = in.next();//"abcd";
	        String result2 = caractersCentrals(input2);
	        System.out.println("El resultat és: "+result2);  
	        
	        in.close();
	    }

	    public static String caractersCentrals(String str) {
	        int longitud = str.length();

	        if (longitud % 2 == 0) {
	            // Longitud parella, retorna els dos caràcters centrals
	            int mig1 = longitud / 2 - 1;
	            int mig2 = longitud / 2;
	            return str.substring(mig1, mig2 + 1);
	        } else {
	            // Longitud senar, retorna el caràcter central
	            int mig = longitud / 2;
	            return String.valueOf(str.charAt(mig));
	        }
	    }
	}
