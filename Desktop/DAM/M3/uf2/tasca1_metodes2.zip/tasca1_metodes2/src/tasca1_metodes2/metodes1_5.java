package tasca1_metodes2;
import java.util.Scanner;
public class metodes1_5 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int numero;

		do {
			System.out.print("Introdueix un número enter (entre el 1 i el 3999): ");
			numero = scanner.nextInt();

			if (numero > 0 && numero < 4000) {
				String numeroRomano = convertirANumerosRomanos(numero);
				String numeroCatala = convertirACatala(numero);

				System.out.println("En romà: " + numeroRomano);
				System.out.println("En català: " + numeroCatala);
			} else if (numero >= 4000) {
				System.out.println("Número fora de rang.");
			}
		} while (numero >= 0);
		scanner.close();
	}


	public static String convertirANumerosRomanos(int numero) {
		String[] simbolos = {"I", "IV", "V", "IX", "X", "XL", "L", "XC", "C", "CD", "D", "CM", "M"};
		int[] valores = {1, 4, 5, 9, 10, 40, 50, 90, 100, 400, 500, 900, 1000};

		StringBuilder resultado = new StringBuilder();
		int indice = valores.length - 1;

		while (numero > 0) {
			if (numero >= valores[indice]) {
				resultado.append(simbolos[indice]);
				numero -= valores[indice];
			} else {
				indice--;
			}
		}

		return resultado.toString();
	}

	public static String convertirACatala(int numero) {
		String[] unidades = {"", "u", "dos", "tres", "quatre", "cinc", "sis", "set", "vuit", "nou"};
		String[] decenas = {"", "", "vint", "trenta", "quaranta", "cinquanta", "seixanta", "setanta", "vuitanta", "noranta"};

		int unidad = numero % 10;
		int decena = (numero / 10) % 10;
		int centena = (numero / 100) % 10;
		int millar = (numero / 1000) % 10;

		StringBuilder resultado = new StringBuilder();

		if (millar > 0) {
			resultado.append(unidades[millar]).append(" mil");
			if (centena > 0 || decena > 0 || unidad > 0) {
				resultado.append(" ");
			}
		}

		if (centena > 0) {
			resultado.append(unidades[centena]).append("cents");
			if (decena > 0 || unidad > 0) {
				resultado.append(" ");
			}
		}

		if (decena == 1) {
			resultado.append("i").append(unidades[unidad]);
		} else {
			resultado.append(decenas[decena]);
			if (decena > 0 && unidad > 0) {
				resultado.append("-");
			}
			resultado.append(unidades[unidad]);
		}

		return resultado.toString();
	}
}


