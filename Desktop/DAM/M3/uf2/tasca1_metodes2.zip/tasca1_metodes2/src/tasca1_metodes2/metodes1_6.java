package tasca1_metodes2;
import java.util.Scanner;
public class metodes1_6 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.print("Introduce un número: ");
		int numero = scanner.nextInt();

		mostrarTablasMultiplicar(numero);
		scanner.close();
	}

	public static void mostrarTablasMultiplicar(int numero) {
		for (int i = 1; i <= numero; i++) {
			System.out.println("Tabla de multiplicar del " + i + ":");
			mostrarTablaMultiplicar(i);
			System.out.println();
		}
	}

	public static void mostrarTablaMultiplicar(int numero) {
		for (int i = 1; i <= 10; i++) {
			System.out.println(numero + " x " + i + " = " + (numero * i));
		}
	}
}


