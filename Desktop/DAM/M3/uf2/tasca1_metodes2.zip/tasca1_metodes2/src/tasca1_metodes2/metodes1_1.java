package tasca1_metodes2;

import java.util.*;

public class metodes1_1 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce una frase:");
        String inputFrase = scanner.nextLine();

        String fraseBarajada = barajarFrase(inputFrase);
        System.out.println("Frase barajada: " + fraseBarajada);
        scanner.close();
    }

    public static String intercambiarLetras(String palabra) {
        if (palabra.length() <= 3) {
            return palabra;
        }

        Random rand = new Random();
        int longitud = palabra.length();
        int indice1 = rand.nextInt(longitud - 2) + 1;
        int indice2;
        do {
            indice2 = rand.nextInt(longitud - 2) + 1;
        } while (indice1 == indice2);

        char[] caracteres = palabra.toCharArray();
        char temporal = caracteres[indice1];
        caracteres[indice1] = caracteres[indice2];
        caracteres[indice2] = temporal;

        return new String(caracteres);
    }

    public static String barajarFrase(String frase) {
        String[] palabras = frase.split(" ");
        List<String> palabrasBarajadas = new ArrayList<>();

        for (String palabra : palabras) {
            palabrasBarajadas.add(intercambiarLetras(palabra));
        }

        return String.join(" ", palabrasBarajadas);
    }
}
