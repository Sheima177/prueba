package tasca1_metodes2;
import java.util.Scanner;
public class metodes1_4{

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int numero;
		do {
			System.out.print("Introduce un número entre 1 y 3999 (o un número negativo para salir): ");
			numero = scanner.nextInt();

			if (numero > 0 && numero < 4000) {
				String numeroRomano = convertirANumerosRomanos(numero);
				System.out.println("Número romano: " + numeroRomano);
			} else if (numero >= 4000) {
				System.out.println("Número fuera de rango.");
			}
		} while (numero >= 0);
		scanner.close();
	}


	public static String convertirANumerosRomanos(int numero) {
		String[] simbolos = { "I", "IV", "V", "IX", "X", "XL", "L", "XC", "C", "CD", "D", "CM", "M" };
		int[] valores = { 1, 4, 5, 9, 10, 40, 50, 90, 100, 400, 500, 900, 1000 };

		StringBuilder resultado = new StringBuilder();

		int indice = valores.length - 1;

		while (numero > 0) {
			if (numero >= valores[indice]) {
				resultado.append(simbolos[indice]);
				numero -= valores[indice];
			} else {
				indice--;
			}
		}

		return resultado.toString();

	}
}


