package tasca1_metodes2;
import java.util.Scanner;
public class metodes1_3 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int numero;

		do {
			System.out.print("Introduce un número positivo menor que 10000 (o un número negativo para salir): ");
			numero = scanner.nextInt();

			if (numero >= 0 && numero < 10000) {
				String nombre = convertirNumero(numero);
				System.out.println(nombre);
			} else if (numero >= 10000) {
				System.out.println("Número fuera de rango.");
			}
		} while (numero >= 0);
		scanner.close();
	}


	public static String convertirNumero(int numero) {
		String[] unidades = { "", "u", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve" };
		String[] decenas = { "", "", "veinte", "treinta", "cuarenta", "cincuenta", "sesenta", "setenta", "ochenta", "noventa" };
		String[] centenas = { "", "cien", "doscientos", "trescientos", "cuatrocientos", "quinientos", "seiscientos", "setecientos", "ochocientos", "novecientos" };

		int unidad = numero % 10;
		int decena = (numero / 10) % 10;
		int centena = (numero / 100) % 10;
		int millar = (numero / 1000) % 10;

		StringBuilder resultado = new StringBuilder();

		if (millar > 0) {
			resultado.append(unidades[millar]).append(" mil");
			if (centena > 0 || decena > 0 || unidad > 0) {
				resultado.append(" ");
			}
		}

		if (centena > 0) {
			resultado.append(centenas[centena]);
			if (decena > 0 || unidad > 0) {
				resultado.append(" ");
			}
		}

		if (decena == 1) {
			resultado.append("veinti").append(unidades[unidad]);
		} else {
			resultado.append(decenas[decena]);
			if (decena > 0 && unidad > 0) {
				resultado.append("-");
			}
			resultado.append(unidades[unidad]);
		}

		return resultado.toString();
	}
}
