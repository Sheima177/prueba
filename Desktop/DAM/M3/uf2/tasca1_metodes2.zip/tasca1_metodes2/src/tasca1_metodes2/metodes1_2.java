package tasca1_metodes2;
import java.util.Scanner;
public class metodes1_2 {



	public class Main {
		public static void main(String[] args) {
			Scanner in = new Scanner(System.in);
			double d = llegirFinsDouble(in, "Introdueix un número: ");
			System.out.println("El número introducido es: " + d);
		}

		public static double llegirFinsDouble(Scanner in, String prompt) {
			double num = 0;
			boolean valid = false;

			do {
				System.out.print(prompt);
				if (in.hasNextDouble()) {
					num = in.nextDouble();
					valid = true;
				} else {
					System.out.println("Entrada no vàlida. Si us plau, introdueix un número vàlid.");
					in.next(); // Descarta la entrada incorrecta para evitar un bucle infinito
				}
			} while (!valid);

			return num;
		}
	}
}





