package Payments;

public class cash extends payment {
        float cashTendered;

}
