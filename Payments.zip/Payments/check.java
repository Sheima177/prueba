package Payments;

public class check extends payment {
        String name;
        String bankID;


}
