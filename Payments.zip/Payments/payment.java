package Payments;

public abstract class payment {
    private float amount;

}
